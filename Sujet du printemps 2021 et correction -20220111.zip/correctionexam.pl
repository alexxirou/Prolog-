%partie1: Listes
%question1
add([],_,[]).
add([X|L], A ,[Y|L1]):- Y is X+A, add(L, A, L1).
%question2
range(X,Y,L):- rangeb(X,Y,0,L).

rangeb(X,Y,N,[N|L]):- N>X-1, N<Y+1, N1 is N+1, rangeb(X,Y,N1,L),!.
rangeb(X,Y,N,L):- N<X, N1 is N+1, rangeb(X,Y,N1,L),!.
rangeb(_,Y,N,[]):- N>Y.

%question3
union([],L,L).
union([X|Y],L1,[X|Z]) :- not(member(X,L1)), union(Y,L1,Z).
union([X|Y],L1,Z) :- member(X,L1), union(Y,L1,Z).

inter([],_,[]).
inter([X|Y],L1,[X|Z]):- member(X,L1), inter(Y,L1,Z).
inter([_|Y],L1,Z):- inter(Y,L1,Z).

%partie2:base de faits

equipement(jean,[bottes,bonnet,pull]).
equipement(paul,[parapluie,sandales,kway,short,gants]).
equipement(jacques,[bob,moufles]).

temps(nord,[froid,pluie]).
temps(sud,[soleil]).
temps(est,[neige,froid]).
temps(ouest,[pluie,chaud]).

equipe(froid,[pull,bonnet,gants,echarpe]).
equipe(pluie,[parapluie,kway]).
equipe(soleil,[sandales,bob,short,lunettes]).
equipe(neige,[pull,moufles,gants]).
equipe(chaud,[sandales,short]).

%Question1
listeregion(R,L):-
  temps(R,L1),
  listeregion1(L1,[],L).

listeregion1([],L,L).
listeregion1([X|Y],L1,L):-
 equipe(X,L2),
 union(L2,L1,L3),
 listeregion1(Y,L3,L).


%Question2
listepersonne(L):-listepersonne1([],L).
listepersonne1(A,Z):- equipement(X,_), not(member(X,A)),!,listepersonne1([X|A],Z).
listepersonne1(A,A).

%Question3
listescore([],_,[]).
listescore([X|Y],L,[(X,R)|Z]):- equipement(X,L1), inter(L,L1,L2), 
                                 length(L2,R), listescore(Y,L,Z).


%Question4
maxscore(L,P):- maxscore1(L,(_,0),(P,_)).

maxscore1([],A,A):-!.
maxscore1([(P,Z)|Y],(_,A),B):- Z > A, maxscore1(Y,(P,Z),B).
maxscore1([_|Y],A,B):- maxscore1(Y,A,B).


